﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Speech.Synthesis;
using System.Speech.Recognition;
using System.IO;
using System.Media;
using System.Diagnostics;

namespace Artemis
{
    public partial class MiniArtemis : Form
    {

        SpeechRecognitionEngine MiniArtemisListens = new SpeechRecognitionEngine();
        SpeechSynthesizer MiniArtemisSpeaks = new SpeechSynthesizer();
        DateTime dateTime = DateTime.UtcNow.Date;
        string name1 = "Lorence"; //user name
        static int counter = 0;

        public MiniArtemis()
        {
            MiniArtemisListens.SpeechRecognized += new EventHandler<SpeechRecognizedEventArgs>(HeyArtemis);
            LoadGrammar();
            MiniArtemisListens.SetInputToDefaultAudioDevice(); //default audio microphone
            MiniArtemisListens.RecognizeAsync(RecognizeMode.Multiple);  //recognition of voice
            InitializeComponent();
        }

        private void LoadGrammar() //grammar
        {
            Choices texts = new Choices();
            string[] lines = File.ReadAllLines(Environment.CurrentDirectory + "\\commands.txt");
            texts.Add(lines);
            Grammar wordlist = new Grammar(new GrammarBuilder(texts));
            MiniArtemisListens.LoadGrammar(wordlist);
        }

        private void HeyArtemis(object sender, SpeechRecognizedEventArgs e)
        {
            richTextBox1.Text = e.Result.Text;
            string request = e.Result.Text;
            switch (request)
            {
                case "Hey Artemis":
                    MiniArtemisSpeaks.Speak("Yes?");
                    SoundPlayer ding = new SoundPlayer();
                    ding.SoundLocation = @"Synthetic Waterdrop.wav";
                    ding.Play();
                    MiniArtemisListens.SpeechRecognized += new EventHandler<SpeechRecognizedEventArgs>(MiniArtemisListens_SecondCommand); //seconcommand is the recognised
                    break;
            }
        }

        private void MiniArtemisListens_SecondCommand(object sender, SpeechRecognizedEventArgs e)
        {

            richTextBox1.Text = e.Result.Text;
            string speech = e.Result.Text;
            switch (speech)
            {
                //Basic Commands

                case "How are you?":
                    MiniArtemisSpeaks.Speak("I am fine" + name1);
                    HeyArtemis(sender, e);
                    break;

                case "Where are you?":
                    MiniArtemisSpeaks.Speak("I am on a computer");
                    HeyArtemis(sender, e);
                    break;

                case "What time is it?": //time
                    MiniArtemisSpeaks.Speak("The time is " + DateTime.Now.ToString("hh:mm tt")); //hour:minutes
                    HeyArtemis(sender, e);
                    break;

                case "What is the date today?":
                    MiniArtemisSpeaks.Speak("The date is" + DateTime.Now.ToString("dddd,dd MMMM yyyy")); //day-months-year
                    HeyArtemis(sender, e);
                    break;

                case "What is your name?":
                    MiniArtemisSpeaks.Speak("My name is Artemis, your digital assistant");
                    HeyArtemis(sender, e);
                    break;

                case "What are you?":
                    MiniArtemisSpeaks.Speak("Artemis, a digital assistant and I am developed by " + name1);
                    HeyArtemis(sender, e);
                    break;


                //Advanced Commands

                case "Open Google": //opens google
                    MiniArtemisSpeaks.Speak("Opening Google");
                    Process.Start("chrome.exe", "https://google.com");
                    HeyArtemis(sender, e);
                    break;

                case "Go to YouTube": //opens google and visits youtube
                    MiniArtemisSpeaks.Speak("Opening browser... going to YouTube");
                    Process.Start("chrome.exe", "https://youtube.com");
                    HeyArtemis(sender, e);
                    MiniArtemisListens.SpeechRecognized -= new EventHandler<SpeechRecognizedEventArgs>(MiniArtemisListens_SecondCommand);
                    break;

                case "Close Artemis": //exit artemis
                    MiniArtemisSpeaks.Speak("Goodbye!" + name1);
                    SoundPlayer sp = new SoundPlayer();
                    sp.SoundLocation = @"Soft Pad.wav";
                    sp.Play();
                    Environment.Exit(1);
                    break;

                case "Open Steam": //open steam
                    MiniArtemisSpeaks.Speak("Opening...");
                    Process.Start("C:/Program Files (x86)/Steam/Steam.exe");
                    HeyArtemis(sender, e);
                    MiniArtemisListens.SpeechRecognized -= new EventHandler<SpeechRecognizedEventArgs>(MiniArtemisListens_SecondCommand);
                    break;

                case "Open DDLC": //open doki doki literature club
                    MiniArtemisSpeaks.Speak("Opening DDLC...");
                    MiniArtemisSpeaks.Speak("Just Monika");
                    Process.Start("C:/Program Files (x86)/Steam/steamapps/common/Doki Doki Literature Club/DDLC.exe");
                    HeyArtemis(sender, e);
                    MiniArtemisListens.SpeechRecognized -= new EventHandler<SpeechRecognizedEventArgs>(MiniArtemisListens_SecondCommand);
                    break;

                case "Open Penguins": //open flightless
                    MiniArtemisSpeaks.Speak("Opening Flightless...");
                    Process.Start("C:/Program Files (x86)/Steam/steamapps/common/Flightless/flightless-x64.exe");
                    HeyArtemis(sender, e);
                    MiniArtemisListens.SpeechRecognized -= new EventHandler<SpeechRecognizedEventArgs>(MiniArtemisListens_SecondCommand);
                    break;

                case "Hide Artemis":
                    MiniArtemisSpeaks.Speak("Hiding...");
                    Hide();
                    HeyArtemis(sender, e);
                    MiniArtemisListens.SpeechRecognized -= new EventHandler<SpeechRecognizedEventArgs>(MiniArtemisListens_SecondCommand);
                    break;

                case "Show Artemis":
                    MiniArtemisSpeaks.Speak("Showing...");
                    Show();
                    HeyArtemis(sender, e);
                    MiniArtemisListens.SpeechRecognized -= new EventHandler<SpeechRecognizedEventArgs>(MiniArtemisListens_SecondCommand);
                    break;

                case "Open Fusion 360":
                    MiniArtemisSpeaks.Speak("Opening Fusion three sixty...");
                    Process.Start("C:/FusionLauncher.exe");
                    HeyArtemis(sender, e);
                    break;

                case "Open Main Menu":
                    MiniArtemisSpeaks.Speak("Opening Artemis Main Menu...");
                    StartUp MainMenu = new StartUp();
                    MainMenu.Show();
                    this.Hide();
                    break;

                case "Change to Background1": //change background 1
                    MiniArtemisSpeaks.Speak("Changing...");
                    ChangeBackground1();
                    HeyArtemis(sender, e);
                    break;

                case "Change to Default Background": //change default background
                    MiniArtemisSpeaks.Speak("Changing to Default...");
                    ChangeBackgroundDefault();
                    HeyArtemis(sender, e);
                    break;

                case "Change to Background2": //change background 2
                    MiniArtemisSpeaks.Speak("Changing...");
                    ChangeBackground2();
                    HeyArtemis(sender, e);
                    break;

                case "Change to Background3": //change background 3
                    MiniArtemisSpeaks.Speak("Changing...");
                    ChangeBackground3();
                    HeyArtemis(sender, e);
                    break;

                case "Minimize Artemis":
                    MiniArtemisSpeaks.Speak("Minimizing");
                    Form MiniArtemis = new Form();
                    MiniArtemis.Show();
                    this.Hide();
                    HeyArtemis(sender, e);
                    break;

                case "Go to Spotify":
                    MiniArtemisSpeaks.Speak("Opening...");

                    break;


            }
        }

        private void ChangeBackgroundDefault()
        {
            System.Drawing.Image image = new Bitmap(@"Cool Wallpaper.jpg");
            this.BackgroundImage = image;
        }

        private void ChangeBackground2()
        {
            System.Drawing.Image image = new Bitmap(@"Background2.jpg");
            this.BackgroundImage = image;
        }

        private void ChangeBackground1()
        {
            System.Drawing.Image image = new Bitmap(@"Background1.jpg");
            this.BackgroundImage = image;
        }

        private void ChangeBackground3()
        {
            System.Drawing.Image image = new Bitmap(@"Background3.jpg");
            this.BackgroundImage = image;
        }













        private void button1_Click(object sender, EventArgs e)
        {
            Environment.Exit(1);
        }
    }
}
