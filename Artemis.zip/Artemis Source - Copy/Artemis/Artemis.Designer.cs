﻿namespace Artemis
{
    partial class Artemis
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(Artemis));
            this.richTextBox1 = new System.Windows.Forms.RichTextBox();
            this.label1 = new System.Windows.Forms.Label();
            this.Exit = new System.Windows.Forms.Button();
            this.ArtemisLabel = new System.Windows.Forms.Label();
            this.dateTimePicker1 = new System.Windows.Forms.DateTimePicker();
            this.AnimationTime = new System.Windows.Forms.Timer(this.components);
            this.ArtemisPicture = new System.Windows.Forms.PictureBox();
            this.ArtemisAnimation = new System.Windows.Forms.ImageList(this.components);
            ((System.ComponentModel.ISupportInitialize)(this.ArtemisPicture)).BeginInit();
            this.SuspendLayout();
            // 
            // richTextBox1
            // 
            this.richTextBox1.BackColor = System.Drawing.Color.Blue;
            this.richTextBox1.ForeColor = System.Drawing.Color.White;
            this.richTextBox1.Location = new System.Drawing.Point(16, 236);
            this.richTextBox1.Name = "richTextBox1";
            this.richTextBox1.Size = new System.Drawing.Size(418, 99);
            this.richTextBox1.TabIndex = 0;
            this.richTextBox1.Text = "";
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.BackColor = System.Drawing.Color.Transparent;
            this.label1.Font = new System.Drawing.Font("Microsoft Sans Serif", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.ForeColor = System.Drawing.Color.White;
            this.label1.Location = new System.Drawing.Point(12, 200);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(78, 24);
            this.label1.TabIndex = 1;
            this.label1.Text = "Ask me!";
            // 
            // Exit
            // 
            this.Exit.BackColor = System.Drawing.Color.Transparent;
            this.Exit.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.Exit.ForeColor = System.Drawing.Color.White;
            this.Exit.Location = new System.Drawing.Point(359, 5);
            this.Exit.Name = "Exit";
            this.Exit.Size = new System.Drawing.Size(75, 20);
            this.Exit.TabIndex = 2;
            this.Exit.Text = "Exit";
            this.Exit.UseVisualStyleBackColor = false;
            this.Exit.Click += new System.EventHandler(this.Exit_Click);
            // 
            // ArtemisLabel
            // 
            this.ArtemisLabel.AutoSize = true;
            this.ArtemisLabel.BackColor = System.Drawing.Color.Transparent;
            this.ArtemisLabel.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.ArtemisLabel.ForeColor = System.Drawing.Color.White;
            this.ArtemisLabel.Location = new System.Drawing.Point(13, 9);
            this.ArtemisLabel.Name = "ArtemisLabel";
            this.ArtemisLabel.Size = new System.Drawing.Size(80, 16);
            this.ArtemisLabel.TabIndex = 3;
            this.ArtemisLabel.Text = "Artemis v1.9";
            // 
            // dateTimePicker1
            // 
            this.dateTimePicker1.CalendarForeColor = System.Drawing.Color.Transparent;
            this.dateTimePicker1.CalendarMonthBackground = System.Drawing.Color.Transparent;
            this.dateTimePicker1.Cursor = System.Windows.Forms.Cursors.Hand;
            this.dateTimePicker1.Location = new System.Drawing.Point(129, 5);
            this.dateTimePicker1.Name = "dateTimePicker1";
            this.dateTimePicker1.Size = new System.Drawing.Size(200, 20);
            this.dateTimePicker1.TabIndex = 4;
            // 
            // AnimationTime
            // 
            this.AnimationTime.Enabled = true;
            this.AnimationTime.Interval = 200;
            this.AnimationTime.Tick += new System.EventHandler(this.AnimationTime_Tick);
            // 
            // ArtemisPicture
            // 
            this.ArtemisPicture.BackColor = System.Drawing.Color.Transparent;
            this.ArtemisPicture.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("ArtemisPicture.BackgroundImage")));
            this.ArtemisPicture.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.ArtemisPicture.InitialImage = ((System.Drawing.Image)(resources.GetObject("ArtemisPicture.InitialImage")));
            this.ArtemisPicture.Location = new System.Drawing.Point(12, 47);
            this.ArtemisPicture.Name = "ArtemisPicture";
            this.ArtemisPicture.Size = new System.Drawing.Size(150, 150);
            this.ArtemisPicture.SizeMode = System.Windows.Forms.PictureBoxSizeMode.CenterImage;
            this.ArtemisPicture.TabIndex = 5;
            this.ArtemisPicture.TabStop = false;
            // 
            // ArtemisAnimation
            // 
            this.ArtemisAnimation.ImageStream = ((System.Windows.Forms.ImageListStreamer)(resources.GetObject("ArtemisAnimation.ImageStream")));
            this.ArtemisAnimation.TransparentColor = System.Drawing.Color.MidnightBlue;
            this.ArtemisAnimation.Images.SetKeyName(0, "Slide10.PNG");
            this.ArtemisAnimation.Images.SetKeyName(1, "Slide11.PNG");
            this.ArtemisAnimation.Images.SetKeyName(2, "Slide12.PNG");
            this.ArtemisAnimation.Images.SetKeyName(3, "Slide13.PNG");
            this.ArtemisAnimation.Images.SetKeyName(4, "Slide14.PNG");
            this.ArtemisAnimation.Images.SetKeyName(5, "Slide15.PNG");
            this.ArtemisAnimation.Images.SetKeyName(6, "Slide16.PNG");
            this.ArtemisAnimation.Images.SetKeyName(7, "Slide17.PNG");
            this.ArtemisAnimation.Images.SetKeyName(8, "Slide18.PNG");
            this.ArtemisAnimation.Images.SetKeyName(9, "Slide19.PNG");
            this.ArtemisAnimation.Images.SetKeyName(10, "Slide20.PNG");
            this.ArtemisAnimation.Images.SetKeyName(11, "Slide21.PNG");
            // 
            // Artemis
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("$this.BackgroundImage")));
            this.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.ClientSize = new System.Drawing.Size(1366, 768);
            this.Controls.Add(this.ArtemisPicture);
            this.Controls.Add(this.dateTimePicker1);
            this.Controls.Add(this.ArtemisLabel);
            this.Controls.Add(this.Exit);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.richTextBox1);
            this.ForeColor = System.Drawing.SystemColors.ControlText;
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.None;
            this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
            this.Name = "Artemis";
            this.Text = "Artemis";
            this.WindowState = System.Windows.Forms.FormWindowState.Maximized;
            ((System.ComponentModel.ISupportInitialize)(this.ArtemisPicture)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.RichTextBox richTextBox1;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Button Exit;
        private System.Windows.Forms.Label ArtemisLabel;
        private System.Windows.Forms.DateTimePicker dateTimePicker1;
        private System.Windows.Forms.Timer AnimationTime;
        private System.Windows.Forms.PictureBox ArtemisPicture;
        private System.Windows.Forms.ImageList ArtemisAnimation;
    }
}

