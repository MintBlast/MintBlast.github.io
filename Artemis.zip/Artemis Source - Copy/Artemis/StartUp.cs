﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Speech.Synthesis;
using System.Media;
using System.Collections;
using System.Globalization;
using System.Resources;
using Artemis.Properties;

namespace Artemis
{
    public partial class StartUp : Form
    {

        public StartUp()
        {
            InitializeComponent();
            Welcome();
        }

        private void Welcome()
        {
            SpeechSynthesizer WelcomeArtemis = new SpeechSynthesizer();
            SoundPlayer welcome = new SoundPlayer();
            welcome.SoundLocation = @"Soft Pad.wav";
            welcome.Play();
            WelcomeArtemis.Speak("Welcome!");
        }

        private void StartButton_Click(object sender, EventArgs e)
        {
            Form Artemis = new Artemis();
            Artemis.Show();
            this.Hide();

            SoundPlayer sp = new SoundPlayer();
            sp.SoundLocation = @"Soft Echo Sweep.wav"; //startup sound
            sp.Play();
        }

        private void Exit_Click(object sender, EventArgs e)
        {
            Environment.Exit(1);
        }

        private void button1_Click(object sender, EventArgs e)
        {
            System.Drawing.Image image = new Bitmap(@"Background1.jpg");
            this.BackgroundImage = image;
        }

        private void button2_Click(object sender, EventArgs e)
        {
            System.Drawing.Image image = new Bitmap(@"Background2.jpg");
            this.BackgroundImage = image;
        }

        private void button3_Click(object sender, EventArgs e)
        {
            System.Drawing.Image image = new Bitmap(@"Background3.jpg");
            this.BackgroundImage = image;
        }

        private void button4_Click(object sender, EventArgs e)
        {
            System.Drawing.Image image = new Bitmap(@"Cool Wallpaper.jpg");
            this.BackgroundImage = image;
        }
    }
    }

